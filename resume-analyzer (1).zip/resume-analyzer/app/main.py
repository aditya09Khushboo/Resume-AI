from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from .analyzer import analyze
from .pdf import ResumeFileError, extract_text
from .schemas import AnalyzeResponse
from .skills import get_extractor

MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MIN_JD_CHARS = 30
MAX_JD_CHARS = 20_000

@asynccontextmanager
async def lifespan(_app: FastAPI):
    get_extractor()  # load the skill list once, so the first request is not slow
    yield


app = FastAPI(
    lifespan=lifespan,
    title="Resume Analyzer API",
    version="1.0.0",
    description="Scores a PDF resume against a job description. Files are processed in "
                "memory and never stored; resume text is never logged.",
)


@app.exception_handler(ResumeFileError)
def resume_file_error(_request, exc: ResumeFileError):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


# Plain `def` (not async): parsing and scoring are CPU-bound, so FastAPI runs this in a
# worker thread instead of blocking the event loop.
@app.post("/analyze", response_model=AnalyzeResponse)
def analyze_endpoint(
    resume: UploadFile = File(..., description="Resume as a text-based PDF (max 5 MB, 5 pages)"),
    job_description: str = Form(..., description="Job description text"),
    job_title: str | None = Form(None, description="Optional; defaults to the first line of the JD"),
) -> AnalyzeResponse:
    jd = job_description.strip()
    if len(jd) < MIN_JD_CHARS:
        raise HTTPException(422, f"job_description is too short (minimum {MIN_JD_CHARS} characters).")
    if len(jd) > MAX_JD_CHARS:
        raise HTTPException(413, f"job_description is too long (maximum {MAX_JD_CHARS} characters).")

    data = resume.file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Resume file is larger than 5 MB.")

    text = extract_text(data)
    return analyze(text, jd, job_title)
