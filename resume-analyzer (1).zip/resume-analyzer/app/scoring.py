import re
from dataclasses import dataclass

from sklearn.feature_extraction.text import TfidfVectorizer

# These numbers are judgement calls, not fitted values. Tune them against labelled data
# (see eval/evaluate.py) and report what you changed.
WEIGHTS = {"skills": 0.50, "similarity": 0.25, "title_match": 0.10, "quality": 0.15}
LISTED_ONLY_CREDIT = 0.6   # skill is in the Skills list but not shown in any bullet
PREFERRED_WEIGHT = 0.5     # nice-to-have skills count half as much as required ones
SIM_CEILING = 0.30         # TF-IDF cosine at/above this counts as a full similarity score
MIN_NUMBER_RATIO = 0.30    # share of experience/project lines that should contain a number

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_TITLE_STOP = {"senior", "junior", "sr", "jr", "lead", "intern", "and", "of", "the",
               "a", "an", "for", "at", "remote", "hybrid", "i", "ii", "iii"}


def skills_score(required: set[str], preferred: set[str],
                 in_evidence: set[str], in_listed: set[str]) -> float | None:
    items = [(s, 1.0) for s in required] + [(s, PREFERRED_WEIGHT) for s in preferred]
    if not items:
        return None

    def credit(skill: str) -> float:
        if skill in in_evidence:
            return 1.0
        return LISTED_ONLY_CREDIT if skill in in_listed else 0.0

    total = sum(w for _, w in items)
    return sum(w * credit(s) for s, w in items) / total


def similarity_score(resume_text: str, jd_text: str) -> float:
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
    try:
        matrix = vectorizer.fit_transform([resume_text, jd_text])
    except ValueError:  # empty vocabulary
        return 0.0
    cosine = float(matrix[0].multiply(matrix[1]).sum())  # rows are L2-normalised
    return min(cosine / SIM_CEILING, 1.0)


def guess_title(jd_text: str, explicit: str | None) -> str | None:
    if explicit and explicit.strip():
        return explicit.strip()
    for line in jd_text.splitlines():
        line = line.strip()
        if line:
            ok = len(line.split()) <= 8 and not line.endswith((".", ":"))
            return line if ok else None
    return None


def title_score(title: str | None, resume_text: str) -> float | None:
    if not title:
        return None
    keywords = [t for t in re.findall(r"[a-z+#.]+", title.lower()) if t not in _TITLE_STOP]
    if not keywords:
        return None
    # compare 5-letter prefixes so "engineer" matches "engineering"
    prefixes = {w[:5] for w in re.findall(r"[a-z+#.]+", resume_text.lower())}
    return sum(1 for k in keywords if k[:5] in prefixes) / len(keywords)


@dataclass
class Quality:
    score: float
    checks: dict[str, bool]
    words: int
    evidence_lines: int
    with_numbers: int
    number_ratio: float


def quality_score(sections: dict[str, str], resume_text: str) -> Quality:
    words = len(resume_text.split())
    lines = [
        ln for key in ("experience", "projects")
        for ln in sections.get(key, "").splitlines() if len(ln.split()) >= 5
    ]
    with_numbers = sum(1 for ln in lines if re.search(r"\d", ln))
    ratio = with_numbers / len(lines) if lines else 0.0

    checks = {
        "has_skills_section": "skills" in sections,
        "has_education_section": "education" in sections,
        "has_experience_or_projects": bool({"experience", "projects"} & sections.keys()),
        "has_email": bool(EMAIL_RE.search(resume_text)),
    }
    if 250 <= words <= 900:
        length = 1.0
    elif words < 250:
        length = words / 250
    else:
        length = max(0.0, 1 - (words - 900) / 900)

    parts = [float(v) for v in checks.values()] + [min(ratio / MIN_NUMBER_RATIO, 1.0), length]
    return Quality(sum(parts) / len(parts), checks, words, len(lines), with_numbers, ratio)


def combine(parts: dict[str, float | None]) -> float:
    """Weighted mean over the parts that are available (weights are renormalised)."""
    available = {k: v for k, v in parts.items() if v is not None}
    total = sum(WEIGHTS[k] for k in available)
    return sum(WEIGHTS[k] * v for k, v in available.items()) / total
