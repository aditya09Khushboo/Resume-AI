from pydantic import BaseModel


class Breakdown(BaseModel):
    """Each part is 0-100, or null when it could not be computed."""

    skills: int | None
    similarity: int | None
    title_match: int | None
    quality: int | None


class AnalyzeResponse(BaseModel):
    score: int
    breakdown: Breakdown
    matched_skills: list[str]
    missing_skills: list[str]
    missing_preferred_skills: list[str]
    skills_listed_only: list[str]
    sections_found: list[str]
    suggestions: list[str]
    warnings: list[str]
