import json
import re
from functools import lru_cache
from pathlib import Path

import spacy
from spacy.matcher import PhraseMatcher
from spacy.tokens import Span
from spacy.util import filter_spans

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "skills.json"

# Separators are replaced with spaces in both the text and the skill terms, so
# "C++/Java" and "CI/CD" tokenize the same way on both sides.
_SEPARATORS = re.compile(r"[/|,;:()\[\]•·●▪◦■]")

_PREFERRED_HINT = re.compile(
    r"nice[- ]to[- ]have|preferred|bonus|good to have|a plus|is a plus|plus points", re.I
)
_REQUIRED_HINT = re.compile(
    r"requirements?|required|must[- ]have|responsibilit|qualifications|what you.ll", re.I
)


def _norm(text: str) -> str:
    return _SEPARATORS.sub(" ", text)


class SkillExtractor:
    def __init__(self, path: Path = DATA_FILE):
        entries = json.loads(path.read_text(encoding="utf-8"))["skills"]
        self.nlp = spacy.blank("en")  # tokenizer only; no model download needed
        self._ci = PhraseMatcher(self.nlp.vocab, attr="LOWER")
        self._cs = PhraseMatcher(self.nlp.vocab)  # exact case, for ambiguous names
        for entry in entries:
            name = entry["name"]
            aliases = entry.get("aliases", [])
            if entry.get("case_sensitive"):
                # Only the listed spellings (e.g. "Go", "R", "C"); never the bare name.
                self._cs.add(name, [self.nlp.make_doc(_norm(a)) for a in aliases])
            else:
                terms = [name, *aliases]
                self._ci.add(name, [self.nlp.make_doc(_norm(t)) for t in terms])

    def extract(self, text: str) -> set[str]:
        doc = self.nlp.make_doc(_norm(text))
        spans = []
        for matcher in (self._ci, self._cs):
            for match_id, start, end in matcher(doc):
                spans.append(Span(doc, start, end, label=match_id))
        # overlapping matches (e.g. "c" inside "c++") keep the longest one
        return {self.nlp.vocab.strings[s.label] for s in filter_spans(spans)}

    def split_jd_skills(self, jd_text: str) -> tuple[set[str], set[str]]:
        """Return (required, preferred) skills found in a job description.

        A short heading such as "Nice to have" switches mode for the lines under it;
        a line that says "preferred" or "a plus" is preferred on its own.
        """
        required: set[str] = set()
        preferred: set[str] = set()
        mode = "required"
        for raw in jd_text.splitlines():
            line = raw.strip()
            if not line:
                continue
            short = len(line.split()) <= 8
            if short and _PREFERRED_HINT.search(line):
                mode = "preferred"
            elif short and _REQUIRED_HINT.search(line):
                mode = "required"
            is_preferred = mode == "preferred" or bool(_PREFERRED_HINT.search(line))
            (preferred if is_preferred else required).update(self.extract(line))
        return required, preferred - required


@lru_cache(maxsize=1)
def get_extractor() -> SkillExtractor:
    return SkillExtractor()
