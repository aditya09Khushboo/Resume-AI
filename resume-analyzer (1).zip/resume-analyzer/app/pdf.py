import unicodedata
from io import BytesIO

from pypdf import PdfReader

MAX_PAGES = 5
MIN_CHARS = 100


class ResumeFileError(Exception):
    def __init__(self, status_code: int, detail: str):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


def extract_text(data: bytes, max_pages: int = MAX_PAGES) -> str:
    """Extract text from PDF bytes, entirely in memory (nothing is written to disk)."""
    if not data.startswith(b"%PDF"):
        raise ResumeFileError(415, "File is not a PDF.")
    try:
        reader = PdfReader(BytesIO(data))
        if reader.is_encrypted and not reader.decrypt(""):
            raise ResumeFileError(422, "PDF is password protected.")
        if len(reader.pages) > max_pages:
            raise ResumeFileError(
                422, f"PDF has {len(reader.pages)} pages; the limit is {max_pages}."
            )
        text = "\n".join((page.extract_text() or "") for page in reader.pages)
    except ResumeFileError:
        raise
    except Exception:
        raise ResumeFileError(422, "Could not read this PDF; it may be corrupted.")

    text = unicodedata.normalize("NFKC", text)  # fixes ligatures like "fi"
    if len(text.strip()) < MIN_CHARS:
        raise ResumeFileError(
            422,
            "No readable text found. This looks like a scanned or image-only PDF "
            "(OCR is not supported).",
        )
    return text
