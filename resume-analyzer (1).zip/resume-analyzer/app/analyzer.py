from .schemas import AnalyzeResponse, Breakdown
from .scoring import (combine, guess_title, quality_score, similarity_score,
                      skills_score, title_score)
from .sections import split_sections
from .skills import get_extractor
from .suggestions import build_suggestions


def analyze(resume_text: str, jd_text: str, job_title: str | None = None) -> AnalyzeResponse:
    extractor = get_extractor()
    warnings: list[str] = []

    sections = split_sections(resume_text)
    if set(sections) <= {"header"}:
        warnings.append(
            "No section headings (Experience, Skills, ...) were detected. The layout may be "
            "unusual (for example two columns), so scores are less reliable."
        )

    listed = extractor.extract(sections.get("skills", ""))
    evidence_text = "\n".join(v for k, v in sections.items() if k != "skills")
    evidence = extractor.extract(evidence_text)
    found = listed | evidence

    required, preferred = extractor.split_jd_skills(jd_text)
    if not (required or preferred):
        warnings.append("No known skills were found in the job description; the skills score was left out.")

    skills = skills_score(required, preferred, evidence, listed)
    similarity = similarity_score(resume_text, jd_text)
    title = guess_title(jd_text, job_title)
    title_match = title_score(title, resume_text)
    quality = quality_score(sections, resume_text)

    overall = combine({
        "skills": skills, "similarity": similarity,
        "title_match": title_match, "quality": quality.score,
    })

    missing_required = sorted(required - found)
    missing_preferred = sorted(preferred - found)
    listed_only = sorted(((required | preferred) & listed) - evidence)

    pct = lambda v: None if v is None else round(v * 100)  # noqa: E731
    return AnalyzeResponse(
        score=round(overall * 100),
        breakdown=Breakdown(skills=pct(skills), similarity=pct(similarity),
                            title_match=pct(title_match), quality=pct(quality.score)),
        matched_skills=sorted((required | preferred) & found),
        missing_skills=missing_required,
        missing_preferred_skills=missing_preferred,
        skills_listed_only=listed_only,
        sections_found=[k for k in sections if k != "header"],
        suggestions=build_suggestions(
            missing_required=missing_required, missing_preferred=missing_preferred,
            listed_only=listed_only, quality=quality, title=title, title_match=title_match),
        warnings=warnings,
    )
