import re

SECTION_ALIASES: dict[str, list[str]] = {
    "summary": ["summary", "professional summary", "profile", "objective",
                "career objective", "about me", "about"],
    "experience": ["experience", "work experience", "professional experience",
                   "employment", "employment history", "work history",
                   "internship", "internships"],
    "projects": ["projects", "personal projects", "academic projects", "project work"],
    "skills": ["skills", "technical skills", "key skills", "core competencies",
               "technologies", "skills & tools", "tech stack"],
    "education": ["education", "academic background", "qualifications",
                  "academic qualifications"],
    "extras": ["certifications", "certificates", "achievements", "awards",
               "publications", "activities", "extracurricular activities"],
}

_LOOKUP = {alias: name for name, aliases in SECTION_ALIASES.items() for alias in aliases}


def _norm(line: str) -> str:
    return re.sub(r"[^a-z& ]", "", line.lower()).strip()


def split_sections(text: str) -> dict[str, str]:
    """Split resume text on known headings. Text before the first heading is 'header'."""
    parts: dict[str, list[str]] = {"header": []}
    current = "header"
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        key = _LOOKUP.get(_norm(line)) if len(line) <= 40 else None
        if key:
            current = key
            parts.setdefault(key, [])
            continue
        parts.setdefault(current, []).append(line)
    return {k: "\n".join(v) for k, v in parts.items() if v}
