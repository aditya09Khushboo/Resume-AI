from .scoring import MIN_NUMBER_RATIO, Quality


def build_suggestions(*, missing_required: list[str], missing_preferred: list[str],
                      listed_only: list[str], quality: Quality,
                      title: str | None, title_match: float | None) -> list[str]:
    out: list[str] = []

    if missing_required:
        out.append(
            "The job lists these required skills that your resume does not mention: "
            f"{', '.join(missing_required[:6])}. If you genuinely have them, add them to "
            "Skills and show them in a project or experience bullet. Leave out anything "
            "you could not discuss in an interview."
        )
    if listed_only:
        verb, pron = ("appears", "it") if len(listed_only[:5]) == 1 else ("appear", "them")
        out.append(
            f"{', '.join(listed_only[:5])} {verb} only in your Skills list. Show {pron} in "
            "use inside a project or experience bullet; that is stronger evidence than a list."
        )
    if missing_preferred:
        out.append(
            f"Nice-to-have skills you could add if true: {', '.join(missing_preferred[:5])}."
        )

    if quality.evidence_lines == 0:
        out.append("Add an Experience or Projects section with bullets describing what you built.")
    elif quality.number_ratio < MIN_NUMBER_RATIO:
        out.append(
            f"Only {quality.with_numbers} of {quality.evidence_lines} lines in Experience/Projects "
            "contain a number. Add measurable results where you can (latency, users, test "
            "count, percentage improvement)."
        )

    labels = {
        "has_skills_section": "Add a clear Skills section so keyword scanners can find your skills.",
        "has_education_section": "Add an Education section.",
        "has_email": "No email address was found; make sure your contact details are in the PDF text.",
    }
    for key, message in labels.items():
        if not quality.checks.get(key, True):
            out.append(message)

    if quality.words < 250:
        out.append(f"The resume is short ({quality.words} words). Add detail on what you built and the results.")
    elif quality.words > 900:
        out.append(f"The resume is long ({quality.words} words). Trim it to the most relevant material.")

    if title and title_match is not None and title_match < 0.5:
        out.append(
            f'The job title is "{title}". If it describes you accurately, use similar wording '
            "in your headline or summary."
        )
    return out[:8]
