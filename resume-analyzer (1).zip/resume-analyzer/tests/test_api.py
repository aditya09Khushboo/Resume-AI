from fastapi.testclient import TestClient

from app.main import app
from tests.helpers import JD_BACKEND, STRONG_RESUME, WEAK_RESUME, make_pdf

client = TestClient(app)


def post(pdf: bytes, jd: str = JD_BACKEND, name="resume.pdf"):
    return client.post("/analyze", files={"resume": (name, pdf, "application/pdf")},
                       data={"job_description": jd})


def test_health():
    assert client.get("/health").json() == {"status": "ok"}


def test_strong_beats_weak():
    strong = post(make_pdf(STRONG_RESUME)).json()
    weak = post(make_pdf(WEAK_RESUME)).json()
    assert strong["score"] >= weak["score"] + 20
    assert {"python", "fastapi", "docker"} <= set(strong["matched_skills"])
    assert "kubernetes" in strong["missing_skills"]
    assert "skills" in strong["sections_found"]
    assert any("kubernetes" in s for s in strong["suggestions"])
    assert "python" in weak["missing_skills"]


def test_not_a_pdf():
    r = post(b"hello, this is plain text " * 10)
    assert r.status_code == 415


def test_pdf_without_text():
    from io import BytesIO
    from reportlab.pdfgen import canvas
    buf = BytesIO()
    c = canvas.Canvas(buf)
    c.line(10, 10, 200, 200)
    c.save()
    r = post(buf.getvalue())
    assert r.status_code == 422 and "scanned" in r.json()["detail"]


def test_jd_too_short():
    assert post(make_pdf(STRONG_RESUME), jd="Python").status_code == 422


def test_too_large():
    big = b"%PDF-" + b"0" * (5 * 1024 * 1024 + 10)
    assert post(big).status_code == 413
