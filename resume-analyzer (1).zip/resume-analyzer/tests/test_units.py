from app.sections import split_sections
from app.skills import SkillExtractor

ex = SkillExtractor()


def test_symbols_and_separators():
    found = ex.extract("Experienced in C++/Java, CI/CD pipelines and Node.js services")
    assert {"c++", "java", "ci/cd", "node.js"} <= found
    assert "c" not in found  # "C" inside "C++" must not count as the C language


def test_aliases():
    assert {"javascript", "postgresql", "kubernetes"} <= ex.extract("JS, Postgres and k8s")


def test_case_sensitive_names():
    # Only exact-case "Go"/"Golang" count, so the lowercase verb is ignored.
    # (Known limit: a sentence that starts with "Go ..." will still match.)
    assert "go" not in ex.extract("we plan to go to market in May")
    assert "go" in ex.extract("Backend services in Go")
    assert "go" in ex.extract("Services written in Golang")
    assert {"c", "r", "python"} <= ex.extract("Languages: C, R, Python")
    assert "c" not in ex.extract("vitamin c intake")


def test_no_false_positive_on_common_words():
    found = ex.extract("The rest of the team will express concerns")
    assert "rest apis" not in found and "express.js" not in found


def test_jd_required_vs_preferred():
    jd = "Requirements\nPython and Docker\nNice to have\nRedis\nKubernetes is a plus"
    required, preferred = ex.split_jd_skills(jd)
    assert {"python", "docker"} <= required
    assert {"redis", "kubernetes"} <= preferred


def test_sections():
    text = "Name\nSKILLS\nPython\nProjects:\nBuilt a thing\nEducation\nBCA"
    s = split_sections(text)
    assert set(s) == {"header", "skills", "projects", "education"}
    assert s["skills"] == "Python"
