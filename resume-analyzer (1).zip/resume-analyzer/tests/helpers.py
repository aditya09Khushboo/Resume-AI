from io import BytesIO

JD_BACKEND = """Backend Developer
We are hiring a backend developer to build and run our APIs.

Requirements
- Strong Python and FastAPI experience
- PostgreSQL and Docker
- Designing REST APIs
- Kubernetes basics

Nice to have
- Redis
- AWS
"""

STRONG_RESUME = [
    "Asha Verma",
    "asha.verma@example.com | Hazaribagh, India",
    "SUMMARY",
    "Backend developer building REST APIs with Python and FastAPI.",
    "SKILLS",
    "Python, FastAPI, PostgreSQL, Redis, Docker, Git, Linux",
    "PROJECTS",
    "URL Shortener - built 4 microservices with Node.js and Nginx; Redis caching cut redirects to 12 ms",
    "Resume Analyzer - FastAPI service using pypdf and spaCy, tested on 50 sample resumes",
    "EXPERIENCE",
    "Backend Intern, Acme Labs - wrote 30 unit tests with pytest and cut API errors by 40 percent",
    "Deployed Docker services on AWS and set up monitoring for 5 production APIs",
    "EDUCATION",
    "BCA, Example University, 2027",
]

WEAK_RESUME = [
    "Ravi Kumar",
    "ravi.kumar@example.com | Ranchi, India",
    "SUMMARY",
    "Marketing executive focused on social media and brand storytelling for retail clients.",
    "SKILLS",
    "Photoshop, Excel, Canva, content calendars, copywriting",
    "EXPERIENCE",
    "Marketing Executive, Bright Retail - ran social media campaigns across 3 platforms",
    "Planned monthly content calendars and coordinated with designers and photographers",
    "EDUCATION",
    "BBA, Example College, 2022",
]


def make_pdf(lines: list[str]) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = BytesIO()
    pdf = canvas.Canvas(buf, pagesize=A4)
    pdf.setFont("Helvetica", 9)
    y = 800
    for line in lines:
        pdf.drawString(40, y, line)
        y -= 14
    pdf.save()
    return buf.getvalue()
