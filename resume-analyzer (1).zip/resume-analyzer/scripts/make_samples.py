"""Write sample resumes (fake people) and a job description into samples/."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tests.helpers import JD_BACKEND, STRONG_RESUME, WEAK_RESUME, make_pdf  # noqa: E402

out = ROOT / "samples"
out.mkdir(exist_ok=True)
(out / "strong_resume.pdf").write_bytes(make_pdf(STRONG_RESUME))
(out / "weak_resume.pdf").write_bytes(make_pdf(WEAK_RESUME))
(out / "jd_backend.txt").write_text(JD_BACKEND, encoding="utf-8")
print("wrote samples/")
