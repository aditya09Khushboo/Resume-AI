# Resume Analyzer API

FastAPI service that scores a PDF resume against a job description and returns specific
suggestions. Files are processed in memory and never stored; resume text is never logged.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```

Open http://localhost:8000/docs, or:

```bash
python scripts/make_samples.py          # writes fake sample resumes into samples/
curl -F "resume=@samples/strong_resume.pdf" \
     -F "job_description=<samples/jd_backend.txt" \
     http://localhost:8000/analyze
```

Tests: `pytest`

## API

`POST /analyze` (multipart): `resume` (PDF, max 5 MB, max 5 pages), `job_description`
(text), optional `job_title` (defaults to the first line of the JD).
`GET /health` for the Render health check.

Errors: `415` not a PDF, `413` file or JD too large, `422` scanned/encrypted/corrupt PDF or
JD too short.

## How the score works

| Part | Weight | How |
|---|---|---|
| Skills | 50% | Skills found in the JD (via a curated `data/skills.json` + spaCy `PhraseMatcher`) vs. the resume. Required skills count 1.0, "nice to have" 0.5. A skill shown in a project/experience line gets full credit; one that is only in the Skills list gets 0.6. |
| Similarity | 25% | TF-IDF cosine similarity between resume and JD, scaled so 0.30 = 100%. |
| Title match | 10% | Share of the job title's keywords that appear in the resume. |
| Quality | 15% | Has Skills / Education / Experience-or-Projects sections, has an email, share of experience/project lines containing a number, sensible length. |

If a part cannot be computed (for example no known skills in the JD), its weight is
redistributed over the others and a warning is returned.

**The weights and the 0.30 ceiling are judgement calls, not fitted values.** Tune them
against labelled data and report what you changed.

## Evaluation

```bash
cp eval/labels.example.csv eval/labels.csv   # add 20-30 rows: resume, jd, label
python -m eval.evaluate eval/labels.csv
```

Label each pair (strong / medium / weak) before running the tool, and fix the thresholds
in `eval/evaluate.py` before looking at results. Use your own resume plus fake ones; do
not store other people's resumes.

## Known limits

- Scanned (image-only) PDFs are rejected; there is no OCR.
- Two-column layouts can extract in a jumbled order; the API warns when no section
  headings are found.
- The skill list has about 120 entries. Skills not in it are invisible to the scorer, so
  extend `data/skills.json` for your target roles.
- Exact-case matching for ambiguous names (`Go`, `R`, `C`, `Swift`, `Express`) means a
  sentence starting with "Go ..." can match Go.
- "Experience bullet" detection uses visual lines from the PDF, so wrapped bullets count as
  several lines.
- TF-IDF measures word overlap, not meaning. A planned upgrade is a sentence-embedding
  model behind the same function, compared against TF-IDF on your labelled set.

## Deploy on Render (free tier)

Push to GitHub, create a Blueprint from `render.yaml` (or a Docker web service with health
check path `/health`). Free instances sleep when idle, so the first request after a pause is
slow.
