"""Compare the analyzer's score bands with labels you assigned by hand.

    python -m eval.evaluate eval/labels.csv

CSV columns: resume (PDF path), jd (text file path), label (strong | medium | weak).
Label every pair BEFORE you run the tool, and fix the thresholds below before looking at
results; otherwise you are tuning to your own test set and the agreement number means little.
"""
import csv
import sys
from collections import Counter
from pathlib import Path

from app.analyzer import analyze
from app.pdf import extract_text

STRONG_AT = 70   # score >= 70 -> "strong"
MEDIUM_AT = 45   # score >= 45 -> "medium", otherwise "weak"
LABELS = ["strong", "medium", "weak"]


def band(score: int) -> str:
    return "strong" if score >= STRONG_AT else "medium" if score >= MEDIUM_AT else "weak"


def main(path: str) -> None:
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    confusion: Counter = Counter()
    agree = 0
    for row in rows:
        text = extract_text(Path(row["resume"]).read_bytes())
        jd = Path(row["jd"]).read_text(encoding="utf-8")
        score = analyze(text, jd).score
        predicted, actual = band(score), row["label"].strip().lower()
        confusion[(actual, predicted)] += 1
        agree += predicted == actual
        print(f"{row['resume']:40s} score={score:3d} predicted={predicted:7s} label={actual}")

    print(f"\nAgreement: {agree}/{len(rows)} = {100 * agree / len(rows):.0f}%")
    print("\nrows = your label, columns = predicted band")
    print(" " * 8 + "".join(f"{p:>8s}" for p in LABELS))
    for a in LABELS:
        print(f"{a:8s}" + "".join(f"{confusion[(a, p)]:8d}" for p in LABELS))


if __name__ == "__main__":
    main(sys.argv[1])
